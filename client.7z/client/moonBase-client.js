//io = require('socket.io');

function connectToMoon(){
    let socket = io.connect('https://moon-base.herokuapp.com/');
    return socket;
}